package application.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import application.Main;
import application.controller.EmployeeProfileController;
import application.model.Position;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

/**
 * Employee class loads and adds employees with personal information
 * such as employee ID, password, name, address, phone number, etc.
 */
public class Employee {
	
	private String empID;
	private String password;
	private Position position;
	private String name;
	
	private String DOB;
	private String Addr;
	private String phoneNum;
	private String Email;


	public Employee()
	{
		this.empID = "";
		this.password = "";
	}
	
	public Employee(String empID, String password) {
		this.empID = empID;
		this.password = password;
	}
	
	/**
	 * Gets employee name
	 * @return this.name
	 */
	public String getName()
	{
		return this.name;
	}
	
	/**
	 * Set employee name
	 * @param n
	 */
	public void setName(String n)
	{
		this.name = n;
	}

	/**
	 * Gets employee ID
	 * @return empID
	 */
	public String getEmployeeID() {
		return empID;
	}

	/**
	 * Sets employee ID
	 * @param empID
	 */
	public void setEmployeeID(String empID) {
		this.empID = empID;
	}

	/**
	 * Gets employee password
	 * @return  password
	 */
	public String getPassword() {
		return password;
	}

	
	/**
	 * Sets employee password
	 * @param pass
	 */
	public void setPassword(String pass) {
		this.password = pass;
	}

	
	/**
	 * Method that validates an employee's username and password.
	 * @param username
	 * @param password
	 * @return temp if employee username and password matches
	 * @return null if username and password don't match
	 */
	public Employee validate(String username, String password) {
		 
		 File file = new File("file name here");
		// making sure that the file exists. Looking at the absolute path to fix any path related problem. 
		if(file.exists()) {
		  System.out.println(file.getAbsolutePath());
		 } else {
		  System.out.println("NO FILE!");
		  System.out.println(file.getAbsolutePath());
		 }
		 
		 Scanner scan = null;
		 try {
		  scan = new Scanner(file);
		 }
		 catch (FileNotFoundException e)
		 {
		  e.printStackTrace();
		 }
		 
		 while(scan.hasNextLine() ) {

		  String line = scan.nextLine();
		  String[] word =line.split(",");

		  if(username.equals(word[0])) {
		   if(password.equals(word[1])) {
		 
		    Employee temp = new Employee(username, password);
		    return temp;
		   }
		   
		  }
		 }
		 scan.close();
		 return null;	
	}

	/**
	 * Gets employee's date of birth
	 * @return DOB
	 */
	public String getDOB() {
		return DOB;
	}

	/**
	 * Sets employee's date of birth
	 * @param dOB
	 */
	public void setDOB(String dOB) {
		DOB = dOB;
	}

	/**
	 * Gets employee's address
	 * @return Addr
	 */
	public String getAddr() {
		return Addr;
	}

	/**
	 * Sets employee's address
	 * @param addr
	 */
	public void setAddr(String addr) {
		Addr = addr;
	}

	/**
	 * Gets employee phone number
	 * @return phoneNum
	 */
	public String getPhoneNum() {
		return phoneNum;
	}

	/**
	 * Sets employee phone number
	 * @param phoneNum
	 */
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	/**
	 * Gets employee email
	 * @return Email
	 */
	public String getEmail() {
		return Email;
	}

	/**
	 * Sets employee email
	 * @param email
	 */
	public void setEmail(String email) {
		Email = email;
	}

	/**
	 * Gets employee position
	 * @return position
	 */
	public Position getPosition() {
		return position;
	}

	/**
	 * Sets employee position
	 * @param position
	 */
	public void setPosition(Position position) {
		this.position = position;
	}
	
	
	/**
	 * Checks if an employee already exists on record
	 * @param inputFile
	 * @throws IOException
	 * @return true if employee record is found
	 * @return false if employee does not exist on file
	 */
	public boolean alreadyExists(String inputFile) throws IOException
	{
		//Declare Variables
		String line;
		String[] separatedLine;
		
		//Read File
		File file = new File(inputFile);
		FileReader fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		
		//Parse through file line-by-line and use data 
		while((line = bufferedReader.readLine()) != null)
		{
			separatedLine = parse(line);
			
			if(this.empID.equals(separatedLine[1]))
			{
				bufferedReader.close();
				return true;
			}	
		}
		bufferedReader.close();
		return false;
	}
	
	/**
	 * adds employee info to employees.csv file
	 * @throws IOException
	 */
	public void add() throws IOException
	{
		FileWriter empWriter = new FileWriter("data/employees.csv", true);
		empWriter.append(this.name);
		empWriter.append(",");
		empWriter.append(this.empID);
		empWriter.append(",");
		empWriter.append(this.password);
		empWriter.append(",");
		empWriter.append(this.DOB);
		empWriter.append(",");
		empWriter.append(this.Addr);
		empWriter.append(",");
		empWriter.append(this.phoneNum);
		empWriter.append(",");
		empWriter.append(this.Email);
		empWriter.append(",");
		empWriter.append(this.getPosition().getPosition());
		empWriter.append("\n");
		
		empWriter.flush();
		empWriter.close();
	}
	
	
	/**
	 * Loads and displays employee profile
	 * @param emp
	 */
	public void loadProfile(Employee emp)
	{
		try {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("../view/employeeProfile.fxml"));
		Parent root = loader.load();
		EmployeeProfileController empController = loader.getController();
		Main.scene.setScene(new Scene(root, 800, 800));
		Main.scene.show();
		
		empController.displayLabels("data/employees.csv", emp);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	//Parse through a string
	private String[] parse(String line)
	{
		return line.split(",");
	}
	
	/**
	 * Read employee information that's passed in from data file
	 * @param inputFile
	 * @param employeeID
	 * @throws IOException
	 * 
	 */
	public void loadEmployee(String inputFile, String employeeID) throws IOException
	{
		//Declare Variables
		String line;
		String[] separatedLine;
		
		//Read File
		File file = new File(inputFile);
		FileReader fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		
		//Parse through file line-by-line and use data 
		while((line = bufferedReader.readLine()) != null)
		{
			separatedLine = parse(line);
			
			if(employeeID.equals(separatedLine[1]))
			{
				this.setName(separatedLine[0]);
				this.setEmployeeID(employeeID);
				this.setPassword(separatedLine[2]);
				this.setDOB(separatedLine[3]);
				this.setAddr(separatedLine[4]);
				this.setPhoneNum(separatedLine[5]);
				this.setEmail(separatedLine[6]);
				//this.position.setPosition(separatedLine[7]);
				String pos = separatedLine[7];
				
				if(pos.equals("Intern"))
				{
					Position newPosition = new Position(pos, 10.00, 20.00, "no", 10400);
					this.setPosition(newPosition);
				}
				else if(pos.equals("Seasonal"))
				{
					Position newPosition = new Position(pos, 15.00, 20.00, "no", 3900);
					this.setPosition(newPosition);
				}
				else if(pos.equals("Entry"))
				{
					Position newPosition = new Position(pos, 18.00, 40.00, "no", 37440);
					this.setPosition(newPosition);
				}
				else if(pos.equals("Mid-Level"))
				{
					Position newPosition = new Position(pos, 30.00, 40.00, "no", 62400);
					this.setPosition(newPosition);
				}
				else if(pos.equals("Admin"))
				{
					Position newPosition = new Position(pos, 50.00, 40.00, "yes", 104000);
					this.setPosition(newPosition);
				}
			}	
		}
		bufferedReader.close();
	}

}