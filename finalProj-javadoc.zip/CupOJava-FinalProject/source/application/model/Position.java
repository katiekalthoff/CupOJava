package application.model;

/**
 * Position class implements getters and setters for an employee's position, hourly wage,
 * weekly hours, and salary projections.
 * 
 */

public class Position {
	
	private String position;
	private double hourlyWage = 0.0;
	private double weeklyHours = 0.0;
	private String admin; //yes or no
	
	private int lostSal = 0;
	private int annSal = 0;
	private int projSal = 0;
	
	public Position(){
		
	}
	
	/**
	 * Position constructor that takes in employee information
	 * @param positionTitle
	 * @param hourlyWage
	 * @param hours
	 * @param admin
	 * @param annSal
	 */
	public Position(String positionTitle, double hourlyWage, double hours, String admin, int annSal) {
		this.position = positionTitle;
		this.hourlyWage = hourlyWage;
		this.setWeeklyHours(hours);
		this.admin = admin;
		this.annSal = annSal;
	}
	
	/**
	 * Gets employee position
	 * @return position
	 */
	public String getPosition() {
		return position;
	}
	
	/**
	 * Sets employee postion
	 * @param position
	 */
	public void setPosition(String position) {
		this.position = position;
	}
	
	/**
	 * Gets employee hourly wage
	 * @return hourlyWage
	 */
	public double getHourlyWage() {
		return hourlyWage;
	}
	
	/**
	 * Set employee hourly wage
	 * @param wage
	 */
	public void setHourlyWage(double wage) {
		this.hourlyWage = wage;
	}
	
	/**
	 * Get admin position
	 * @return admin
	 */
	public String getAdmin() {
		return admin;
	}
	
	/**
	 * Sets admin position
	 * @param admin
	 */
	public void setAdmin(String admin) {
		this.admin= admin;
	}
	
	/**
	 * Gets employee's lost salary
	 * @return lostSal
	 */
	public int getLostSal() {
		return lostSal;
	}

	/**
	 * Sets employee's lost salary
	 * @param lostSal
	 */
	public void setLostSal(int lostSal) {
		this.lostSal = lostSal;
	}

	
	/**
	 * Get employee's annual salary
	 * @return annSal
	 */
	public int getAnnSal() {
		return annSal;
	}

	
	/**
	 * Set employee's annual salary
	 * @param annSal
	 */
	public void setAnnSal(int annSal) {
		this.annSal = annSal;
	}

	
	/**
	 * Gets employee's projected salary
	 * @return projSal
	 */
	public int getProjSal() {
		return projSal;
	}

	
	/**
	 *Set employee's projected salary
	 * @param projSal
	 */
	public void setProjSal(int projSal) {
		this.projSal = projSal;
	}

	/**
	 * Gets employee's weekly hours
	 * @return weeklyHours
	 */
	public double getWeeklyHours() {
		return weeklyHours;
	}

	/**
	 * Sets employee's weekly hours
	 * @param weeklyHours
	 */
	public void setWeeklyHours(double weeklyHours) {
		this.weeklyHours = weeklyHours;
	}

	/**
	 * Sets hourly wage as a string
	 * @param string
	 */
	public void setHourlyWageString(String string) {
		String hours = Double.toString(this.hourlyWage);
		
	}

	/**
	 * Sets weekly hours as a string
	 * @param string
	 */
	public void setWeeklyHoursString(String string) {
		String weeklyHrs = Double.toString(this.weeklyHours);
	}

	/**
	 * Sets annual salary as a string
	 * @param string
	 */
	public void setAnnSalString(String string) {
		String annualSal = Integer.toString(this.annSal);
		
	}
	
	/**
	 * Gets hourly wage as a string
	 * @return hours
	 */
	public String getStringHourlyWage()
	{
		String hours = "$" + Double.toString(this.hourlyWage);
		return hours;
	}
	
	/**
	 * Gets weekly hours as a string
	 * @return hours
	 */
	public String getStringWeeklyHours()
	{
		String hours = Double.toString(this.weeklyHours);
		return hours;
	}
	
	
	/**
	 * Gets annual salary as a string
	 * @return hours
	 */
	public String getStringAnnualSalary()
	{
		String hours = "$" + Integer.toString(this.annSal);
		return hours;
	}

}