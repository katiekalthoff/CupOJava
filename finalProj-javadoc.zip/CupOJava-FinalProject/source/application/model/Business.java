package application.model;

public class Business {

}
