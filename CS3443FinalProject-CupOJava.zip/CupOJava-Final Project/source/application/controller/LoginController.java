package application.controller;
/**
 * @author Katie Kalthoff and Daniel Ramirez
 * 
 * LoginController handles when a user logs in. It uses the data file to validate employee's IDs and passwords
 */

import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import application.Main;
import application.model.Employee;
import application.model.Position;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController implements EventHandler<ActionEvent>{

	public String employeeID;
	public String password;
	public String inputFile = "data/employees.csv";
	
	@FXML
	private TextField empIDField;
	
	@FXML
	private PasswordField passwordField;
	
	@FXML
	private Label errorMessage; 
	
	@FXML
	private Button loginButton;
	
	@FXML
	private Button signUpButton;
	
	
	@Override
	public void handle(ActionEvent event) {
		this.employeeID = empIDField.getText();
		this.password = passwordField.getText();

			try {
				if(((Button) event.getSource()).getText().equals(loginButton.getText())) { //login Button

					if(validate(this.employeeID, this.password) == true )
					{
						Employee newEmp = new Employee();
						newEmp.loadEmployee("data/employees.csv", this.employeeID);
						newEmp.loadProfile(newEmp);
					}
					else
					{
						errorMessage.setText("Wrong ID or Password");
						//("Wrong ID or Password");
					}	
				}
				else if(((Button) event.getSource()).getText().equals(signUpButton.getText())) { //sign up button
				
					FXMLLoader loader = new FXMLLoader();
					loader.setLocation(getClass().getResource("../view/signUp.fxml"));
					Parent root = loader.load();
					Main.scene.setScene(new Scene(root, 600, 600));
					Main.scene.show();
				}
	         }
			catch(Exception e){
				e.printStackTrace();
			}
	}
	
    /**
     * this method splits a line on commas that is passed to it 
     * @param line
     * @return
     */
	private String[] parse(String line)
	{
		return line.split(",");
	}
	
	/**
	 * this method is passed an employeeID and password
	 * the data file is looped through to check if the employeeID and password match
	 * an employee. If the employee is valid, it returns true
	 * @param employeeID
	 * @param password
	 * @return
	 * @throws IOException
	 */
	public boolean validate(String employeeID, String password) throws IOException
	{
		//Declare Variables
		String line;
		String[] separatedLine;
		
		//Read File
		File file = new File("data/employees.csv");
		FileReader fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		
		//Parse through file line-by-line and use data 
		while((line = bufferedReader.readLine()) != null)
		{
			separatedLine = parse(line);
			
			if(employeeID.equals(separatedLine[1]) && password.equals(separatedLine[2]))
			{
				bufferedReader.close();
				return true;
			}	
		}
		bufferedReader.close();
		return false;
	}

}