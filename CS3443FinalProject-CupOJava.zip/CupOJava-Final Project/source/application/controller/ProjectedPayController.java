package application.controller;
/**
 * @author Katie Kalthoff and Daniel Ramirez
 * 
 * ProjectedPayController.java handles the ProjectedPay view, check for valid user input, and calculates projected hours and pay
 */

import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;

import application.Main;
import application.model.Employee;
import application.model.Position;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ProjectedPayController {

	
	@FXML
	private TextField inMon1; 
	@FXML
	private TextField outMon1;
	@FXML
	private TextField inTue1;
	@FXML
	private TextField outTue1;
	@FXML
	private TextField inWed1;
	@FXML
	private TextField outWed1;
	@FXML
	private TextField inThur1;
	@FXML
	private TextField outThur1;
	@FXML
	private TextField inFri1;
	@FXML
	private TextField outFri1;
	@FXML
	private TextField inMon2;
	@FXML
	private TextField outMon2;
	@FXML
	private TextField inTue2;
	@FXML
	private TextField outTue2;
	@FXML
	private TextField inWed2;
	@FXML
	private TextField outWed2;
	@FXML
	private TextField inThur2;
	@FXML
	private TextField outThur2;
	@FXML
	private TextField inFri2;
	@FXML
	private TextField outFri2;
	@FXML
	private Label showHoursLabel;
    @FXML
    private Label showPayLabel;
    @FXML
    private Label errorLabel;
    @FXML
    private Button profileButton;
    @FXML
    private Button calculatePay;
    @FXML
    private Button logOut;
    @FXML
    private Label empIDLabel;
    
    /**
     * this method handles the possible buttons that a user will pick in the ProjectedPay view
     * the possible events will change the screen to the login view or to change to the profile view,
     * or calculate the total hours and pay  
     * @param event
     */
	public void handle(ActionEvent event) {

		try  
		{
			if(((Button) event.getSource()).getText().equals(logOut.getText())) { //logout Button

				FXMLLoader loader = new FXMLLoader();
				loader.setLocation(getClass().getResource("../view/Login.fxml"));
				Parent root = loader.load();
				Main.scene.setScene(new Scene(root, 600, 600));
				Main.scene.show();
			}
			else if(((Button) event.getSource()).getText().equals(profileButton.getText())) {
				Employee newEmp = new Employee();
				newEmp.loadEmployee("data/employees.csv", empIDLabel.getText());
				newEmp.loadProfile(newEmp);
				
			}
			else if(((Button) event.getSource()).getText().equals(calculatePay.getText())) {
				

					if (validate() == false){
					//System.out.println("here");
					errorLabel.setText("ERROR: incorrect format or blank fields");
				     }
				else {
				
				String mon1[] = {inMon1.getText(), outMon1.getText()};
				String tue1[] = {inTue1.getText(), outTue1.getText()};
				String wed1[] = {inWed1.getText(), outWed1.getText()};
				String thur1[] = {inThur1.getText(), outThur1.getText()};
				String fri1[] = {inFri1.getText(), outFri1.getText()};
				String mon2[] = {inMon2.getText(), outMon2.getText()};
				String tue2[] = {inTue2.getText(), outTue2.getText()};
				String wed2[] = {inWed2.getText(), outWed2.getText()};
				String thur2[] = {inThur2.getText(), outThur2.getText()};
				String fri2[] = {inFri2.getText(), outFri2.getText()};


				LocalTime in1 = LocalTime.parse (mon1[0]);
				LocalTime out1 = LocalTime.parse(mon1[1]);
				Duration monday1 = Duration.between ( in1 , out1 );
				Duration totalDuration = monday1;


				LocalTime in2 = LocalTime.parse (tue1[0]);
				LocalTime out2 = LocalTime.parse(tue1[1]);

				Duration tuesday1 = Duration.between ( in2 , out2 );
				totalDuration = totalDuration.plus(tuesday1);


				LocalTime in3 = LocalTime.parse (wed1[0]);
				LocalTime out3 = LocalTime.parse(wed1[1]);
				Duration wednesday1 = Duration.between ( in3 , out3 );
				totalDuration = totalDuration.plus(wednesday1);


				LocalTime in4 = LocalTime.parse (thur1[0]);
				LocalTime out4 = LocalTime.parse(thur1[1]);
				Duration thursday1 = Duration.between ( in4 , out4 );
				totalDuration = totalDuration.plus(thursday1);


				LocalTime in5 = LocalTime.parse (fri1[0]);
				LocalTime out5 = LocalTime.parse(fri1[1]);
				Duration friday1 = Duration.between ( in5, out5 );
				totalDuration = totalDuration.plus(friday1);


				LocalTime in6 = LocalTime.parse (mon2[0]);
				LocalTime out6 = LocalTime.parse(mon2[1]);
				Duration monday2 = Duration.between ( in6 , out6 );
				totalDuration = totalDuration.plus(monday2);


				LocalTime in7 = LocalTime.parse (tue2[0]);
				LocalTime out7 = LocalTime.parse(tue2[1]);
				Duration tuesday2 = Duration.between ( in7 , out7 );
				totalDuration = totalDuration.plus(tuesday2);


				LocalTime in8 = LocalTime.parse (wed2[0]);
				LocalTime out8 = LocalTime.parse(wed2[1]);
				Duration wednesday2 = Duration.between ( in8 , out8 );
				totalDuration = totalDuration.plus(wednesday2);


				LocalTime in9 = LocalTime.parse (thur2[0]);
				LocalTime out9 = LocalTime.parse(thur2[1]);
				Duration thursday2 = Duration.between ( in9 , out9 );
				totalDuration = totalDuration.plus(thursday2);


				LocalTime in10 = LocalTime.parse (fri2[0]);
				LocalTime out10 = LocalTime.parse(fri2[1]);
				Duration friday2 = Duration.between ( in10, out10);
				totalDuration = totalDuration.plus(friday2);

				    String stringDuration = String.format("%d:%02d%n", totalDuration.toHours(), totalDuration.minusHours(totalDuration.toHours()).toMinutes());
				    showHoursLabel.setText(stringDuration);
				    Double totalPay = 0.0; 
				    String time[] = stringDuration.split(":");
				    Employee newEmp = new Employee();
				    newEmp.loadEmployee("data/employees.csv", empIDLabel.getText());
				    Position position = newEmp.getPosition();
				    double hourlyWage = position.getHourlyWage();
				    Double hourPay = Double.valueOf(time[0]) * hourlyWage;
				    Double minutePay = (Double.valueOf(time[1])/60) * hourlyWage;
				    totalPay = hourPay + minutePay;
				    String totalPayPrint = String.format("%.2f", totalPay);
				    showPayLabel.setText(totalPayPrint);
				    
				
				}
              
			}}

		    	catch(Exception e)
				{
				e.printStackTrace();

				}
				
		

				
				
			}

    /**
     * this function validates the times that the user inputs.
     * It checks for 5 characters, a correct format, and that the out time is later than the in time
     * @return
     */
	private boolean validate() {
		String mon1[] = {inMon1.getText(), outMon1.getText()};
		String tue1[] = {inTue1.getText(), outTue1.getText()};
		String wed1[] = {inWed1.getText(), outWed1.getText()};
		String thur1[] = {inThur1.getText(), outThur1.getText()};
		String fri1[] = {inFri1.getText(), outFri1.getText()};
		String mon2[] = {inMon2.getText(), outMon2.getText()};
		String tue2[] = {inTue2.getText(), outTue2.getText()};
		String wed2[] = {inWed2.getText(), outWed2.getText()};
		String thur2[] = {inThur2.getText(), outThur2.getText()};
		String fri2[] = {inFri2.getText(), outFri2.getText()};

		LocalTime in1 = LocalTime.parse (mon1[0]);
		LocalTime out1 = LocalTime.parse(mon1[1]);
		if(in1.compareTo(out1) > 0) {
			return false;
		}    	

		LocalTime in2 = LocalTime.parse (tue1[0]);
		LocalTime out2 = LocalTime.parse(tue1[1]);
		if(in2.compareTo(out2) > 0) {
			return false;
		} 

		LocalTime in3 = LocalTime.parse (wed1[0]);
		LocalTime out3 = LocalTime.parse(wed1[1]);
		if(in3.compareTo(out3) > 0) {
			return false;
		} 


		LocalTime in4 = LocalTime.parse (thur1[0]);
		LocalTime out4 = LocalTime.parse(thur1[1]);
		if(in4.compareTo(out4) > 0) {
			return false;
		} 

		LocalTime in5 = LocalTime.parse (fri1[0]);
		LocalTime out5 = LocalTime.parse(fri1[1]);
		if(in5.compareTo(out5) > 0) {
			return false;
		} 

		LocalTime in6 = LocalTime.parse (mon2[0]);
		LocalTime out6 = LocalTime.parse(mon2[1]);
		if(in6.compareTo(out6) > 0) {
			return false;
		} 

		LocalTime in7 = LocalTime.parse (tue2[0]);
		LocalTime out7 = LocalTime.parse(tue2[1]);
		if(in7.compareTo(out7) > 0) {
			return false;
		} 

		LocalTime in8 = LocalTime.parse (wed2[0]);
		LocalTime out8 = LocalTime.parse(wed2[1]);
		if(in8.compareTo(out8) > 0) {
			return false;
		} 

		LocalTime in9 = LocalTime.parse (thur2[0]);
		LocalTime out9 = LocalTime.parse(thur2[1]);
		if(in9.compareTo(out9) > 0) {
			return false;
		} 

		LocalTime in10 = LocalTime.parse (fri2[0]);
		LocalTime out10 = LocalTime.parse(fri2[1]);
		if(in10.compareTo(out10) > 0) {
			return false;
		} 

		if(inMon1.getText().trim().isEmpty() == true || outMon1.getText().trim().isEmpty() == true || inTue1.getText().trim().isEmpty() == true|| outTue1.getText().trim().isEmpty() == true || 
				inWed1.getText().trim().isEmpty() == true || outWed1.getText().trim().isEmpty() == true || inThur1.getText().trim().isEmpty() == true|| 
				outThur1.getText().trim().isEmpty() == true || inFri1.getText().trim().isEmpty() == true || outFri1.getText().trim().isEmpty() == true){
		return false;
		}
		else if(inMon2.getText().trim().isEmpty() == true || outMon2.getText().trim().isEmpty() == true|| inTue2.getText().trim().isEmpty() == true || outTue2.getText().trim().isEmpty() == true || 
				inWed2.getText().trim().isEmpty() == true || outWed2.getText().trim().isEmpty() == true|| inThur2.getText().trim().isEmpty() == true || 
				outThur2.getText().trim().isEmpty() == true|| inFri2.getText().trim().isEmpty() == true|| outFri2.getText().trim().isEmpty() == true) {
			return false;
		}
		else if(inMon1.getText().split(":").length != 2 || outMon1.getText().split(":").length != 2 || inTue1.getText().split(":").length != 2
				|| inWed1.getText().split(":").length != 2 || outWed1.getText().split(":").length != 2 ||  inThur1.getText().split(":").length != 2 
				|| outThur1.getText().split(":").length != 2 || inFri1.getText().split(":").length != 2 || outFri1.getText().split(":").length != 2){
		}
		else if(inMon2.getText().split(":").length != 2 || outMon2.getText().split(":").length != 2 || inTue2.getText().split(":").length != 2
				|| inWed2.getText().split(":").length != 2 || outWed2.getText().split(":").length != 2 ||  inThur2.getText().split(":").length != 2 
				|| outThur2.getText().split(":").length != 2 || inFri2.getText().split(":").length != 2 || outFri2.getText().split(":").length != 2){
			return false;
		}
		else if(inMon1.getText().length() != 5 || outMon1.getText().length() != 5 || inTue1.getText().length() != 5 || outTue1.getText().length() < 5|| 
				inWed1.getText().length() != 5 || outWed1.getText().length() != 5 || inThur1.getText().length() != 5 || 
				outThur1.getText().length() != 5 || inFri1.getText().length() != 5|| outFri1.getText().length() != 5 ){
			return false;		
				}
		else if(inMon2.getText().length() != 5 || outMon2.getText().length() != 5 || inTue2.getText().length() != 5 || outTue1.getText().length() < 5|| 
				inWed2.getText().length() != 5 || outWed2.getText().length() != 5 || inThur2.getText().length() != 5 || 
				outThur2.getText().length() != 5 || inFri2.getText().length() != 5|| outFri2.getText().length() != 5 ){
			return false;
			}

		return true;
		
	}


	/**
	 * this function sets the employee string so that it can be used to access employee position information
	 * @param empID
	 */
	public void displayLabels(String empID)
	{
		empIDLabel.setText(empID);
	}

	
	
}