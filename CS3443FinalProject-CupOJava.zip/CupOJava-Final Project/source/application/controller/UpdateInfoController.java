package application.controller;
/**
 * @author Katie Kalthoff and Daniel Ramirez
 * 
 * UpdateInfoController controls the UpdateInfo view. It takes in an employee id, validates it, then
 * rewrites all new information into the data file 
 * 
 */

import javafx.event.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import application.Main;
import application.model.*;

public class UpdateInfoController implements EventHandler<ActionEvent>
{
	@FXML
	private TextField employeeID;
	@FXML
	private TextField password;
	@FXML
	private TextField employeeName;
	@FXML
	private TextField birthdate;
	@FXML
	private TextField address;
	@FXML
	private TextField phoneNum;
	@FXML
	private TextField email;
	@FXML
	private ComboBox<String> position;
	@FXML
	private Label errorMessage;
	@FXML
	private Label oldEmpID;
	
	@FXML
	public void initialize() {
	    position.getItems().removeAll(position.getItems());
	    position.getItems().addAll("Intern", "Seasonal", "Entry", "Mid-Level", "Admin");
	    position.getSelectionModel().select("Intern");
	}
	
	@FXML
	private Button register;
	
	/**
	 * this method handles what the user inputs and selects in the UpdateInfo view
	 * If the employee id is incorrect, an error message will be displayed
	 * @param event
	 */
	public void handle(ActionEvent event)
	{
		String empID = employeeID.getText();
		String pass = password.getText();
		String name = employeeName.getText();
		String bDay = birthdate.getText();
		String phone = phoneNum.getText();
		String eM = email.getText();
		String addr = address.getText();
		String pos = position.getValue();
		
		Employee newEmp = setEmployee(empID, pass, name, bDay, phone, eM, addr, pos);
		try {
			if(oldEmpID.getText().equals(newEmp.getEmployeeID()))
			{
				removeEmployee("data/employees.csv", newEmp.getEmployeeID());
				newEmp.add();
				newEmp.loadProfile(newEmp);
			}
			else
				errorMessage.setText("Error: Must be an Existing User");
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
//		newEmp.loadProfile(newEmp);
	}
	
	/**
	 * this method displays the id of the employee that is currently updating their profile
	 * @param eID
	 */
	public void displayLabels(String eID)
	{
		oldEmpID.setText(eID);
	}
	
	/**
	 * this method takes a string as a parameter and parses it on commas
	 * @param line
	 * @return
	 */
	//Parse through a string
	private String[] parse(String line)
	{
		return line.split(",");
	}
	
	/**
	 * this method parses through the data file to find the employee that is being updated, and then
	 * write the lines to a string that will be passed to resetFile()
	 * @param inputFile
	 * @param empID
	 * @throws IOException
	 */
	//Read input from passed in data file
	public void removeEmployee(String inputFile, String empID) throws IOException
	{
		//Declare Variables
		String line;
		String[] separatedLine;
		String wholeFile = "";
		
		//Read File
		File file = new File(inputFile);
		FileReader fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		
		//Parse through file line-by-line and use data 
		while((line = bufferedReader.readLine()) != null)
		{
			separatedLine = parse(line);
			
			if(empID.equals(separatedLine[1]))
			{
				continue;
			}
			
			wholeFile += (line + "\n");
		}
		bufferedReader.close();
		resetFile(wholeFile);
	}
	
	/**
	 * this method overwrites the data file with the new file information 
	 * @param wholeFile
	 * @throws IOException
	 */
	public void resetFile(String wholeFile) throws IOException
	{
		FileWriter empWriter = new FileWriter("data/employees.csv");
		empWriter.append(wholeFile);
		
		empWriter.flush();
		empWriter.close();
	}
	
	/**
	 * This method is passed the user input that is read in handle() and creates a new employee with the new information
	 * the employee's position is also set based on their selection
	 * @param empID
	 * @param pass
	 * @param name
	 * @param bDay
	 * @param phone
	 * @param eM
	 * @param addr
	 * @param pos
	 * @return
	 */
	public Employee setEmployee(String empID, String pass, String name, String bDay, String phone, String eM, String addr, String pos)
	{
		//System.out.println("In setEmployee function\n");
		Employee emp = new Employee(empID, pass);
		emp.setName(name);
		emp.setDOB(bDay);
		emp.setPhoneNum(phone);
		emp.setEmail(eM);
		emp.setAddr(addr);
		
		if(pos.equals("Intern"))
		{
			Position newPosition = new Position(pos, 10.00, 20.00, "no", 10400);
			emp.setPosition(newPosition);
		}
		else if(pos.equals("Seasonal"))
		{
			Position newPosition = new Position(pos, 15.00, 20.00, "no", 3900);
			emp.setPosition(newPosition);
		}
		else if(pos.equals("Entry"))
		{
			Position newPosition = new Position(pos, 18.00, 40.00, "no", 37440);
			emp.setPosition(newPosition);
		}
		else if(pos.equals("Mid-Level"))
		{
			Position newPosition = new Position(pos, 30.00, 40.00, "no", 62400);
			emp.setPosition(newPosition);
		}
		else if(pos.equals("Admin"))
		{
			Position newPosition = new Position(pos, 50.00, 40.00, "yes", 104000);
			emp.setPosition(newPosition);
		}
		
		return emp;
	}
	

}
